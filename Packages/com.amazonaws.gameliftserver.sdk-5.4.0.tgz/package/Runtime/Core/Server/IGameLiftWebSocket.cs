﻿/*
* All or portions of this file Copyright (c) Amazon.com, Inc. or its affiliates or
* its licensors.
*
* For complete copyright and license terms please see the LICENSE at the root of this
* distribution (the "License"). All use of this software is governed by the License,
* or, if provided, by the license below or the license accompanying this file. Do not
* remove or modify any license notices. This file is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*
*/

using System;
using Aws.GameLift.Server.Model;
using Aws.GameLift.Server.Security;

namespace Aws.GameLift.Server
{
    public interface IGameLiftWebSocket : IDisposable
    {
        GenericOutcome Connect(
            string websocketUrl,
            string processId,
            string hostId,
            string fleetId,
            string authToken = null,
            string sigV4QueryString = null);

        GenericOutcome Disconnect();

        GenericOutcome SendMessage(Message message);

        bool IsConnected();
    }
}
