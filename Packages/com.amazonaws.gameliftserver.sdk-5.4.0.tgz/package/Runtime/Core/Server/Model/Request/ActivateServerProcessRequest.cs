﻿/*
 * All or portions of this file Copyright (c) Amazon.com, Inc. or its affiliates or
 * its licensors.
 *
 * For complete copyright and license terms please see the LICENSE at the root of this
 * distribution (the "License"). All use of this software is governed by the License,
 * or, if provided, by the license below or the license accompanying this file. Do not
 * remove or modify any license notices. This file is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *
 */

using System.Collections.Generic;

namespace Aws.GameLift.Server.Model
{
    public class ActivateServerProcessRequest : Message
    {
        public string SdkVersion { get; }

        public string SdkLanguage { get; }

        public string SdkToolName { get; }

        public string SdkToolVersion { get; }

        public int Port { get; }

        public IList<string> LogPaths { get; }

        public ActivateServerProcessRequest(string sdkVersion, string sdkLanguage, string sdkToolName, string sdkToolVersion, int port, IList<string> logPaths)
        {
            Action = MessageActions.ActivateServerProcess;
            SdkVersion = sdkVersion;
            SdkLanguage = sdkLanguage;
            SdkToolName = sdkToolName;
            SdkToolVersion = sdkToolVersion;
            Port = port;
            LogPaths = logPaths;
        }
    }
}
